let quizTitle = "Nome do Quiz"
let isClock = true
let useImages = true
let useFinalResultText = false
let numOfQuestions = 2
let questions = ["Questão 1", "Questão 2"]
let answers = [
    ["Q1 - Resposta Correta", "Q1 - Resposta Errada", "Q1 - Resposta Errada", "Q1 - Resposta Errada"],
    ["Q2 - Resposta Correta", "Q2- Resposta Errada", "Q2- Resposta Errada", "Q2- Resposta Errada"],
]
let imgQuestions = ["images/quizImages/placeholder.png", "images/quizImages/placeholder.png"]
let finalResultAll = [
    "🔬 Mestre das Chamas – domina o fogo sem gastar um centavo!",
    "🧪 Alquimista Aprendiz – pronto para a próxima experiência!",
    "💧 Quase deu ruim – melhor misturar um pouco mais de água!",
    "💸 Economista do Caos – queimou o dinheiro e o conteúdo! 😅"
]